import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class HTTPRequest {

    private static HttpURLConnection con;

    public static void main(String[] args) throws IOException {
        doPost();
    }

    public static String doPost() throws IOException {

        // create Output as JSON String
        String outputDataJSONString = "{\"action\" : \"2DWH\", \"callBackUri\" : \"https://dpwesteurope.svc.datafactory.azure.com/dataplane/workflow/callback/47eb4b99-ba58-45f5-ab64-91908c5740ec?callbackUrl=AAEAFHef5QkNXdXQK1Yq4%2bIylAGCaSnaAQBq%2f%2fWrv83LwmBj9WB2k6vwMe4m72%2fCk0Knu1EzRa1QlsH6YsAtsz%2bRHRwFHaaAh2p6c2ldlxmZ%2fwxK%2fnTHcB1aoHawdo0SZ3UeT0AYMQxpYLWFw1LgC5wwEylIe7PZ1MLYRv3%2f4QsDqQvAB9%2bILPTV%2f0p6SGyEkIysquxlNwerdmq4PafOqrbOJ5uVfy5vNLC%2fBJWBZLYOFotpyzcLEgZweh3E8JijDVWtBO4KUejKWrZ4SyvChOFHRPPfGps2f%2b8JnmkGDKd87oVv7Az3eVgQZ8%2fhMNWKTIzEFiRf2qFHklJqYuRPfiimvVfVgF87dIn0xg0MARDxoSzdzwbhPak2ABC7U3mfJwni9s9wirVsojcCAaA0NmP5dshlBrkFETiTDrgzgdFw2iKhZqSKEyXjHzEP%2bSWjoQblsf8nDwU5DHdxdn7V3NtvM8L3eOzTqZxc8gJj5paIJU13xGFZ4ebQDpmvNmqq%2bK8pN6f%2fhJOMCZZ4ghjrb7Obg9YdLBC5GnxpXHb0DIbjMt1HYV9nW2kr346%2bJiT%2bH6E%2bAh154BkWqrWChqIMPoSfdM9q6L1sJ1bWc79DjnZwa7iUA7pvNZlfIkGLevzvoBX3PZu1grOiYuY5ekTvNnXescgPmXUjG5SAPKXi%2bUNsPq2qokY9qO%2bx6OZat66RVAahn8Tbu8SblTg7CuiRpMWJyA4XfKa%2bmg%2b%2fnBaATxRtBLT9YvgLgMgkQGkoW0yjeQBwrA5p%2bvZZEVlYcc4ntTozHs2dDQ5%2bT3vqGYV5hjLzfc7ij0fBM9qYj6wyo0lFOWzqZykFuSxQxJ%2bctF8PCtSxVoVdN3zLuSBGy8V4%2brWBJx1fwMY2O2Kvnz0rLXe3A1iaKU1uak6tzQ0NvKe7Qxj%2bCCN9kXU1V1PZQL3yM%2b5HOpoxulhBkknkwjkOzA%3d%3d&token=AAEAFHef5QkNXdXQK1Yq4%2bIylAGCaSnaAQCiQIGCbv%2bm7RwZZSLPGLcdOz0x7ENr3xySPpGsHVyvoqjZefqAPcpmgO5mkN1w6SBxE3gwwJDfexa7QNYVWwxVyy2yjaoqJZlz8c%2bt61xd37Cybj8%2fOd8E%2b3Ga1GybUB%2fUgqSAf73kg112Jzl0W%2bnwlgk9osQvpCpVWgMmtquS9uoS8YXUyCWikqNkSqKsBxvrNl47dU1cLv0veYPoxwGLM655GADGoHSNh021OOqU7%2b3Ftx24qCwd7A870DQNEhX74tQZe8y4qtpZ0ZcviqyEItFsRen3EjQxSH7oX74w6v1rMe%2b%2fLzZ8c48yuKI7%2fO1WYOXHZIe6jG%2bUqO6aOGtSABCvMDnA6WjAB2qQT2JZrS08AaAPJUrYgsaC72c5Xe1UNo1lG2X5ORKn6J%2f11UABFPtEf4wJg4vUXW56WGTyJXwW1vb32fvM9epXHgQoCZWctKm9hUfmOS1BXXIQU0M4HaJQV%2fzADCqcNXLQN2IXkr3zFSh1nULrxhCop3fphw35aKVA5jDyEBWtbFkP2mwDzPMVuW%2flxYGt8G7WVaC9Zarn8rbupM0s8Jsca5NXkD7H7Jz8iOYfXSYKAswr1BwcfB0cq8PkuXFhCNYbjgR%2fw8seBaOJEiIEgxPylApwZXXliy7hnAb1m3%2bpYwlgWiYp6tiMjDfcAUXlbs5P%2b2tp0uAr1p12%2b3LOV%2fGUFAhMSJEzeUAsZd5q%2b%2bURSOgN9rcnvJJtYHbzLvh6Co6cwvWuerpF20KXLlvQMZ6fiiHmnuCb2lvCFxGWRJLNhM0v7KBGE5Z15W6N3A3tOq8GMj7jzAvLwSEKNDAFbmiCZBzxkEU4cOB%2bq%2fTpCnHEFqGeTbxBH%2b0lpBB8SlTICXYfL9IeQ3NjFggWXfUPV6ac1NyZyFojJB7C8E2sYUf%2f6l4ZlMvWQ6vZlw%3d%3d&activityRunId=13f5a1b3-b01c-4a8e-9df5-bc20cc5feaba&shouldReportToMonitoring=True&pipelineResourceType=Pipeline&activityType=WebHook\"}";
       // System.out.println("JSON-Daten als String: " + outputDataJSONString);

        // transform JSON String to JSON Object
        JSONObject jsonobj = new JSONObject(outputDataJSONString);

        // http connection and request
        URL url = new URL("https://prod-164.westeurope.logic.azure.com:443/workflows/cebafa64e2a44c04b32de62ec8d7ea48/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=FGSkXq_W_h57i8yIUYuQ0Xiw7vVD5cnMEF8iT4yx-dw");
        con = (HttpURLConnection) url.openConnection();
        con.setDoOutput(true);
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestProperty("Accept", "application/json");

        // request body
        OutputStream os = con.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
        osw.write(jsonobj.toString());
        osw.flush();
        osw.close();

        // response
        try(BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
           // System.out.println("Response: " + response);
        }

        return con.getResponseMessage();
    }
}

