import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseConnection {

    public static void main(String[] args) {
        ConnectToDB();
    }

    public static String ConnectToDB(){
        String userName = "supervisor";
        String userPassword = "\"/WVi6s1pW;pB2fHqN53A7eKuQA:ev~Y";
        String cnnStr =
                "jdbc:sqlserver://dSDWH2.database.windows.net;"
                        + "database=dSDWH2_TEST;"
                        + "user=" + userName + ";"
                        + "password={" + userPassword + "};"
                        + "encrypt=true;"
                        + "trustServerCertificate=false;"
                        + "loginTimeout=30;";

        //    String sql = "Select * from target.EMPLOYEE;";

        //    ExecuteSQL(cnnStr, sql);

        ClearDatabase(cnnStr);

        return cnnStr;
    }

    public static void ClearDatabase(String cnnStr) {
        try (Connection cnn = DriverManager.getConnection(cnnStr);
             Statement statement = cnn.createStatement()) {
             statement.executeQuery("TRUNCATE TABLE target.EMPLOYEE;");
        }
        catch (SQLException e) {
            var exception = e.getNextException();
            System.out.println("Exception: " + exception);
        }
    }

    public static List<List<String>> ExecuteSQL(String cnnStr, String sql) {
        ResultSet resultSet = null;
        List<List<String>> allEmployeesList = new ArrayList<>();

        try (Connection cnn = DriverManager.getConnection(cnnStr);
             Statement statement = cnn.createStatement()) {
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                List<String> employeeList = new ArrayList<>();
                System.out.println("Daten abrufen ...");
                employeeList.add(resultSet.getString("EmployeeID"));
                employeeList.add(resultSet.getString("EmployeeFirstname"));
                employeeList.add(resultSet.getString("EmployeeLastname"));
                employeeList.add(resultSet.getString("EmployeeBirthday"));
                employeeList.add(resultSet.getString("SRC_TeamID"));
                employeeList.add(resultSet.getString("EmployeeJobLevel"));
                employeeList.add(resultSet.getString("EmployeeJobLocation"));
                employeeList.add(resultSet.getString("IsCurrent"));
                employeeList.add(resultSet.getString("ValidFrom"));
                employeeList.add(resultSet.getString("ValidTo"));
                System.out.println("employeeList: " + employeeList);
                System.out.println("Daten hinzugefügt!");
                allEmployeesList.add(employeeList);
            }
        // System.out.println("allEmployeesList nach den Schleifen: " + allEmployeesList);
        }
        catch (SQLException e) {
            var exception = e.getNextException();
            System.out.println("Exception: " + exception);
        }

        return allEmployeesList;
    }
}