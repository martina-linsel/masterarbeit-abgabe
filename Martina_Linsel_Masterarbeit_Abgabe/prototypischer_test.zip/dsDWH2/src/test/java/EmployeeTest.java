import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeTest {

    // 3 unterschiedliche Dateien in 2 unterschiedliche Monatsordner in den Lake legen (Januar und Februar)
    // (Datei 2022-01-04 und Datei 2022-02-14 und Datei 2022-02-18)
    // Siehe Kapitel 5.2.1
    @Test
    @DisplayName("UpdateEmployeeSCD2ChangeToSCD1")
    void UpdateExistingSCD2ChangeToSCD1() throws IOException {
        String DBconn;
        List<List<String>> resultEmployeeList = new ArrayList<>();
        List<List<String>> allEmployeesList = new ArrayList<>();
        List<String> employeeListEmp1 = new ArrayList<>();
        List<String> employeeListEmp2 = new ArrayList<>();

        // Testdaten anlegen
        employeeListEmp1.add("123_JUser");
        employeeListEmp1.add("Julia");
        employeeListEmp1.add("Schneider");
        employeeListEmp1.add("1997-01-11");
        employeeListEmp1.add("Team 1");
        employeeListEmp1.add("Trainee");
        employeeListEmp1.add("Jena");
        employeeListEmp1.add("0");
        employeeListEmp1.add("1900-01-01");
        employeeListEmp1.add("2022-01-31");

        employeeListEmp2.add("123_JUser");
        employeeListEmp2.add("Julia");
        employeeListEmp2.add("Schneider");
        employeeListEmp2.add("1997-01-11");
        employeeListEmp2.add("Team 1");
        employeeListEmp2.add("Junior");
        employeeListEmp2.add("Berlin");
        employeeListEmp2.add("1");
        employeeListEmp2.add("2022-02-01");
        employeeListEmp2.add("9999-12-31");

        allEmployeesList.add(employeeListEmp1);
        allEmployeesList.add(employeeListEmp2);

        // Verbindung zur Datenbank aufbauen
        System.out.println("Verbindung zur Datenbank aufbauen ... ");
        DBconn = DatabaseConnection.ConnectToDB();

        // Datenbank leeren
        System.out.println("Datenbank leeren ... ");
        DatabaseConnection.ClearDatabase(DBconn);

        // Logic App starten ( -> Daten zur Datenbank hinzufügen)
        System.out.println("Logic App starten, um die Datenbank zu befüllen ... ");
        String response = HTTPRequest.doPost();
        try {
            Thread.sleep(30000);
        } catch (InterruptedException ignored) {
        }
        System.out.println("Response: " + response);
        Assert.assertEquals("Accepted", response);

        // Daten aus der Datenbank abfragen
        System.out.println("Daten aus der Datenbank abfragen ... ");
        resultEmployeeList = DatabaseConnection.ExecuteSQL(DBconn, "Select * from target.EMPLOYEE;");
        System.out.println("Inhalt der Datenbank: " + resultEmployeeList);
        System.out.println("Inhalt der Liste emp1: " + employeeListEmp1);
        System.out.println("Inhalt der Liste emp3: " + employeeListEmp2);

        // Überprüfung, ob die beiden erwarteten Datensätze in den Daten aus der Datenbank enthalten sind
        Assertions.assertTrue(resultEmployeeList.contains(employeeListEmp1));
        Assertions.assertTrue(resultEmployeeList.contains(employeeListEmp2));
    }



    // Weitere testweise implementierte Tests
    // 1 Datei in den Lake legen
    // (Datei 2022-03-08)
    @Test
    @DisplayName("InsertEmployeeIntoEmptyDB")
    void InsertNonExistingTest() throws IOException {
        String DBconn;
        List<List<String>> resultEmployeeList = new ArrayList<>();
        List<String> employeeListEmp1 = new ArrayList<>();
        List<String> employeeListEmp2 = new ArrayList<>();

        // Testdaten anlegen
        employeeListEmp1.add("123_JUser");
        employeeListEmp1.add("Julia");
        employeeListEmp1.add("Schneider");
        employeeListEmp1.add("1997-01-11");
        employeeListEmp1.add("Team 1");
        employeeListEmp1.add("Trainee");
        employeeListEmp1.add("Jena");
        employeeListEmp1.add("1");
        employeeListEmp1.add("1900-01-01");
        employeeListEmp1.add("9999-12-31");

        employeeListEmp2.add("234_JUser");
        employeeListEmp2.add("Hannah");
        employeeListEmp2.add("Wille");
        employeeListEmp2.add("1995-04-03");
        employeeListEmp2.add("Team 2");
        employeeListEmp2.add("Professional");
        employeeListEmp2.add("Berlin");
        employeeListEmp2.add("1");
        employeeListEmp2.add("1900-01-01");
        employeeListEmp2.add("9999-12-31");

        // Verbindung zur Datenbank aufbauen
        System.out.println("Verbindung zur Datenbank aufbauen ...");
        DBconn = DatabaseConnection.ConnectToDB();

        // Datenbank leeren
        System.out.println("Datenbank leeren ... ");
        DatabaseConnection.ClearDatabase(DBconn);

        // Logic App starten ( -> Daten zur Datenbank hinzufügen)
        System.out.println("Logic App starten, um die Datenbank zu befüllen ...");
        String response = HTTPRequest.doPost();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignored) {
        }
        System.out.println("Response: " + response);
        Assert.assertEquals("Accepted", response);

        // Daten aus der Datenbank abfragen
        System.out.println("Daten aus der Datenbank abfragen ...");
        resultEmployeeList = DatabaseConnection.ExecuteSQL(DBconn, "Select * from target.EMPLOYEE;");
        System.out.println("Inhalt der Datenbank: " + resultEmployeeList);
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp1));
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp2));
    }

    // 2 unterschiedliche Dateien in 2 unterschiedliche Monatsordner in den Lake legen (März und April)
    // (Datei 2022-03-08 und Datei 2022-04-07)
    @Test
    @DisplayName("UpdateEmployeeSCD1")
    void UpdateExistingSCD1Test() throws IOException {
        String DBconn;
        List<List<String>> resultEmployeeList = new ArrayList<>();
        List<String> employeeListEmp1 = new ArrayList<>();
        List<String> employeeListEmp2 = new ArrayList<>();

        // Testdaten anlegen
        employeeListEmp1.add("123_JUser");
        employeeListEmp1.add("Julia");
        employeeListEmp1.add("Schneider");
        employeeListEmp1.add("1997-01-11");
        employeeListEmp1.add("Team 1");
        employeeListEmp1.add("Trainee");
        employeeListEmp1.add("Jena");
        employeeListEmp1.add("1");
        employeeListEmp1.add("1900-01-01");
        employeeListEmp1.add("9999-12-31");

        employeeListEmp2.add("234_JUser");
        employeeListEmp2.add("Hannah");
        employeeListEmp2.add("Wille");
        employeeListEmp2.add("1995-04-04");
        employeeListEmp2.add("Team 2");
        employeeListEmp2.add("Professional");
        employeeListEmp2.add("Berlin");
        employeeListEmp2.add("1");
        employeeListEmp2.add("1900-01-01");
        employeeListEmp2.add("9999-12-31");

        // Verbindung zur Datenbank aufbauen
        System.out.println("Verbindung zur Datenbank aufbauen ...");
        DBconn = DatabaseConnection.ConnectToDB();

        // Datenbank leeren
        System.out.println("Datenbank leeren ... ");
        DatabaseConnection.ClearDatabase(DBconn);

        // Logic App starten ( -> Daten zur Datenbank hinzufügen)
        System.out.println("Logic App starten, um die Datenbank zu befüllen ...");
        String response = HTTPRequest.doPost();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignored) {
        }
        System.out.println("Response: " + response);
        Assert.assertEquals("Accepted", response);

        // Daten aus der Datenbank abfragen
        System.out.println("Daten aus der Datenbank abfragen ...");
        resultEmployeeList = DatabaseConnection.ExecuteSQL(DBconn, "Select * from target.EMPLOYEE;");
        System.out.println("Inhalt der Datenbank: " + resultEmployeeList);
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp1));
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp2));
    }

    // 2 unterschiedliche Dateien in 2 unterschiedliche Monatsordner in den Lake legen (März und April)
    // (Datei 2022-03-08 und Datei 2022-04-08)
    @Test
    @DisplayName("UpdateEmployeeSCD2")
    void UpdateExistingSCD2Test() throws IOException {
        String DBconn;
        List<List<String>> resultEmployeeList = new ArrayList<>();
        List<List<String>> allEmployeesList = new ArrayList<>();
        List<String> employeeListEmp1 = new ArrayList<>();
        List<String> employeeListEmp2 = new ArrayList<>();
        List<String> employeeListEmp3 = new ArrayList<>();
        List<String> employeeListEmp4 = new ArrayList<>();

        // Testdaten anlegen
        employeeListEmp1.add("123_JUser");
        employeeListEmp1.add("Julia");
        employeeListEmp1.add("Schneider");
        employeeListEmp1.add("1997-01-11");
        employeeListEmp1.add("Team 1");
        employeeListEmp1.add("Trainee");
        employeeListEmp1.add("Jena");
        employeeListEmp1.add("0");
        employeeListEmp1.add("1900-01-01");
        employeeListEmp1.add("2022-03-31");

        employeeListEmp2.add("234_JUser");
        employeeListEmp2.add("Hannah");
        employeeListEmp2.add("Wille");
        employeeListEmp2.add("1995-04-03");
        employeeListEmp2.add("Team 2");
        employeeListEmp2.add("Professional");
        employeeListEmp2.add("Berlin");
        employeeListEmp2.add("0");
        employeeListEmp2.add("1900-01-01");
        employeeListEmp2.add("2022-03-31");

        employeeListEmp3.add("123_JUser");
        employeeListEmp3.add("Julia");
        employeeListEmp3.add("Schneider");
        employeeListEmp3.add("1997-01-11");
        employeeListEmp3.add("Team 1");
        employeeListEmp3.add("Trainee");
        employeeListEmp3.add("Berlin");
        employeeListEmp3.add("1");
        employeeListEmp3.add("2022-04-01");
        employeeListEmp3.add("9999-12-31");

        employeeListEmp4.add("234_JUser");
        employeeListEmp4.add("Hannah");
        employeeListEmp4.add("Wille");
        employeeListEmp4.add("1995-04-03");
        employeeListEmp4.add("Team 3");
        employeeListEmp4.add("Professional");
        employeeListEmp4.add("Berlin");
        employeeListEmp4.add("1");
        employeeListEmp4.add("2022-04-01");
        employeeListEmp4.add("9999-12-31");

        allEmployeesList.add(employeeListEmp1);
        allEmployeesList.add(employeeListEmp2);
        allEmployeesList.add(employeeListEmp3);
        allEmployeesList.add(employeeListEmp4);

        // Verbindung zur Datenbank aufbauen
        System.out.println("Verbindung zur Datenbank aufbauen ... ");
        DBconn = DatabaseConnection.ConnectToDB();

        // Datenbank leeren
        System.out.println("Datenbank leeren ... ");
        DatabaseConnection.ClearDatabase(DBconn);

        // Logic App starten ( -> Daten zur Datenbank hinzufügen)
        System.out.println("Logic App starten, um die Datenbank zu befüllen ... ");
        String response = HTTPRequest.doPost();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignored) {
        }
        System.out.println("Response: " + response);
        Assert.assertEquals("Accepted", response);

        // Daten aus der Datenbank abfragen
        System.out.println("Daten aus der Datenbank abfragen ... ");
        resultEmployeeList = DatabaseConnection.ExecuteSQL(DBconn, "Select * from target.EMPLOYEE;");
        System.out.println("Inhalt der Datenbank: " + resultEmployeeList);
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp1));
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp2));
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp3));
        Assert.assertTrue(resultEmployeeList.contains(employeeListEmp4));
    }
}
